/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121_poe;

/**
 *
 * @author ngale
 */
import java.util.Scanner;

public class QuickChat {
    public static void main(String[] args) {
        run(new Scanner(System.in));
    }

    public static void run(Scanner in) {
        System.out.println("Welcome to QuickChat.");
        System.out.print("How many messages do you wish to enter? ");
        int max = Integer.parseInt(in.nextLine().trim());
        int entered = 0;

        while (true) {
            System.out.println("\n1) Send Messages\n2) Show recently sent messages\n3) Quit");
            String option = in.nextLine().trim();
            if (option.equals("1")) {
                if (entered >= max) {
                    System.out.println("You have reached your limit of " + max + " messages.");
                    continue;
                }
                System.out.print("Recipient cell (+countrycode...): ");
                String recipient = in.nextLine().trim();
                Message probe = new Message(recipient, "x");
                String cellResult = probe.checkRecipientCell();
                System.out.println(cellResult);
                if (!cellResult.startsWith("Cell phone number successfully")) continue;

                System.out.print("Message (max 250 chars): ");
                String text = in.nextLine();
                String lengthResult = Message.checkMessageLength(text);
                if (!lengthResult.equals("Success")) {
                    System.out.println(lengthResult);
                    continue;
                }
                Message msg = new Message(recipient, text);
                System.out.println(msg.sentMessage(in));
                System.out.println(msg.details());
                entered++;
            } else if (option.equals("2")) {
                System.out.println("Coming Soon.");
            } else if (option.equals("3")) {
                break;
            } else {
                System.out.println("Please choose 1, 2 or 3.");
            }
        }
        System.out.println("Total messages sent: " + Message.returnTotalMessages());
    }
}

