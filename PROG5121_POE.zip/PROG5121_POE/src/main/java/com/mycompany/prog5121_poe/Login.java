/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121_poe;

/**
 *
 * @author ngale
 */

import java.util.regex.Pattern;

public class Login {
    // "+" then country code (1-3 digits) then number of no more than 10 digits
    private static final Pattern CELL = Pattern.compile("^\\+\\d{1,3}\\d{1,10}$");

    private final String firstName;
    private final String lastName;
    private String username;
    private String password;
    private String cellPhone;

    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Underscore present and no more than five characters
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // At least 8 chars, a capital, a number and a special character
    public boolean checkPasswordComplexity(String password) {
        return password != null
                && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[0-9].*")
                && password.matches(".*[^A-Za-z0-9].*");
    }

    public boolean checkCellPhoneNumber(String cell) {
        return cell != null && CELL.matcher(cell).matches();
    }

    // ---- messages used by the registration rules ----
    public String usernameMessage(String u) {
        return checkUserName(u)
                ? "Username successfully captured."
                : "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
    }

    public String passwordMessage(String p) {
        return checkPasswordComplexity(p)
                ? "Password successfully captured."
                : "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
    }

    public String cellMessage(String c) {
        return checkCellPhoneNumber(c)
                ? "Cell number successfully captured."
                : "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
    }

    // Returns the registration message; stores details only if everything is valid
    public String registerUser(String username, String password, String cell) {
        if (!checkUserName(username)) return usernameMessage(username);
        if (!checkPasswordComplexity(password)) return passwordMessage(password);
        if (!checkCellPhoneNumber(cell)) return cellMessage(cell);
        this.username = username;
        this.password = password;
        this.cellPhone = cell;
        return "User has been registered successfully.";
    }

    public boolean loginUser(String username, String password) {
        return this.username != null
                && this.username.equals(username)
                && this.password.equals(password);
    }

    public String returnLoginStatus(boolean loggedIn) {
        return loggedIn
                ? "Welcome " + firstName + ", " + lastName + " it is great to see you again."
                : "Username or password incorrect, please try again.";
    }
}
