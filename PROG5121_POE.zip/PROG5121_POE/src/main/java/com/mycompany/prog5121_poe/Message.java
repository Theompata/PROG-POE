/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121_poe;

/**
 *
 * @author ngale
 */
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

public class Message {
    private static final Pattern CELL = Pattern.compile("^\\+\\d{1,3}\\d{1,10}$");
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static final Random RANDOM = new Random();
    private static int totalSent = 0;
    private static int created = 0;   // running message number (starts at 0)

    private final String messageId;
    private final int messageNumber;
    private final String recipient;
    private final String text;
    private final String hash;

    public Message(String recipient, String text) {
        this.messageId = String.valueOf(1_000_000_000L + (long) (RANDOM.nextDouble() * 9_000_000_000L));
        this.messageNumber = created++;
        this.recipient = recipient;
        this.text = text;
        this.hash = createMessageHash();
    }

    // ---- validation ----
    public boolean checkMessageID() {
        return messageId.length() <= 10;
    }

    public String checkRecipientCell() {
        return CELL.matcher(recipient).matches()
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code, please correct the number and try again.";
    }

    public static String checkMessageLength(String text) {
        return text.length() <= 250
                ? "Success"
                : "Please enter a message of less than 250 characters.";
    }

    // ---- hash: first 2 digits of ID : message number : FIRSTLAST ----
    public String createMessageHash() {
        String[] words = text.trim().split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        return (messageId.substring(0, 2) + ":" + messageNumber + ":" + first + last).toUpperCase();
    }

    // ---- send / disregard / store (testable version) ----
    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                sentMessages.add(this);
                totalSent++;
                return "Message successfully sent";
            case 2:
                return "Press 0 to delete the message";
            case 3:
                storedMessages.add(this);
                storeMessage();
                return "Message successfully stored";
            default:
                return "Invalid option";
        }
    }

    // ---- interactive version ----
    public String sentMessage(Scanner in) {
        System.out.println("1) Send Message  2) Disregard Message  3) Store Message to send later");
        int choice = readInt(in);
        String result = sentMessage(choice);
        if (choice == 2) {
            System.out.println(result);
            result = readInt(in) == 0 ? "Message deleted" : "Message kept (not sent)";
        }
        return result;
    }

    private static int readInt(Scanner in) {
        try { return Integer.parseInt(in.nextLine().trim()); }
        catch (NumberFormatException e) { return -1; }
    }

    // ---- reporting ----
    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) sb.append(m.details()).append("\n");
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return totalSent;
    }

    public String details() {
        return "Message ID: " + messageId + "\nMessage Hash: " + hash
                + "\nRecipient: " + recipient + "\nMessage: " + text + "\n";
    }

    // ---- JSON storage (no external library) ----
    public static void storeMessage() {
        StringBuilder sb = new StringBuilder("[\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            Message m = storedMessages.get(i);
            sb.append("  {\"messageId\": \"").append(m.messageId)
              .append("\", \"messageHash\": \"").append(esc(m.hash))
              .append("\", \"recipient\": \"").append(esc(m.recipient))
              .append("\", \"message\": \"").append(esc(m.text)).append("\"}")
              .append(i < storedMessages.size() - 1 ? ",\n" : "\n");
        }
        sb.append("]");
        try (FileWriter fw = new FileWriter("messages.json")) {
            fw.write(sb.toString());
        } catch (IOException e) {
            System.out.println("Could not write JSON file: " + e.getMessage());
        }
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    public static void resetAll() {
        sentMessages.clear(); storedMessages.clear(); totalSent = 0; created = 0;
    }

    public String getMessageID() { return messageId; }
    public int getMessageNumber() { return messageNumber; }
    public String getHash() { return hash; }
}
