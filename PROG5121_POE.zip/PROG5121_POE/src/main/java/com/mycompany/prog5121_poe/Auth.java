/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121_poe;

/**
 *
 * @author ngale
 */
import java.util.Scanner;

/** Console flow for registration + login (Part 1). */
public class Auth {
    public static boolean run(Scanner in) {
        System.out.print("First name: ");
        String first = in.nextLine().trim();
        System.out.print("Last name: ");
        String last = in.nextLine().trim();
        Login login = new Login(first, last);

        String user;
        do {
            System.out.print("Create username: ");
            user = in.nextLine().trim();
            System.out.println(login.usernameMessage(user));
        } while (!login.checkUserName(user));

        String pass;
        do {
            System.out.print("Create password: ");
            pass = in.nextLine();
            System.out.println(login.passwordMessage(pass));
        } while (!login.checkPasswordComplexity(pass));

        String cell;
        do {
            System.out.print("Cell phone number (e.g. +27838968976): ");
            cell = in.nextLine().trim();
            System.out.println(login.cellMessage(cell));
        } while (!login.checkCellPhoneNumber(cell));

        System.out.println(login.registerUser(user, pass, cell));

        System.out.println("\n--- Login ---");
        for (int attempt = 1; attempt <= 3; attempt++) {
            System.out.print("Username: ");
            String u = in.nextLine().trim();
            System.out.print("Password: ");
            String p = in.nextLine();
            boolean ok = login.loginUser(u, p);
            System.out.println(login.returnLoginStatus(ok));
            if (ok) return true;
        }
        return false;
    }
}
