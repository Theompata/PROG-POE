/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog5121_poe;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {
    private Message m1, m2;

    @BeforeEach void setUp() {
        Message.resetAll();
        m1 = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight?");
        m2 = new Message("08575975889", "Hi Keegan, did you receive the payment?");
    }

    @Test void messageLengthSuccess() {
        assertEquals("Success", Message.checkMessageLength("Hi Mike, can you join us for dinner tonight?"));
    }
    @Test void messageLengthFailure() {
        assertEquals("Please enter a message of less than 250 characters.", Message.checkMessageLength("a".repeat(251)));
    }
    @Test void recipientSuccess() {
        assertEquals("Cell phone number successfully captured.", m1.checkRecipientCell());
    }
    @Test void recipientFailure() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code, please correct the number and try again.", m2.checkRecipientCell());
    }
    @Test void hashCorrect() {
        assertEquals(m1.getMessageID().substring(0, 2) + ":" + m1.getMessageNumber() + ":HITONIGHT", m1.createMessageHash());
    }
    @Test void messageIdCreated() {
        assertTrue(m1.checkMessageID());
        assertEquals(10, m1.getMessageID().length());
    }
    @Test void sendMessage() {
        assertEquals("Message successfully sent", m1.sentMessage(1));
    }
    @Test void disregardMessage() {
        assertEquals("Press 0 to delete the message", m2.sentMessage(2));
    }
    @Test void storeMessage() {
        assertEquals("Message successfully stored", m1.sentMessage(3));
    }
    @Test void totalMessagesSent() {
        m1.sentMessage(1);   // sent; m2 is discarded
        assertEquals(1, Message.returnTotalMessages());
    }
    @Test void printMessagesContainsSent() {
        m1.sentMessage(1);
        assertTrue(Message.printMessages().contains("Hi Mike, can you join us for dinner tonight?"));
    }
}
