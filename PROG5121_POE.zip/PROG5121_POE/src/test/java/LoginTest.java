/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog5121_poe;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {
    private final Login login = new Login("Kyle", "Smith");

    @Test void usernameCorrect() {
        assertEquals("Username successfully captured.", login.usernameMessage("kyl_1"));
    }
    @Test void usernameIncorrect() {
        assertEquals("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.",
                login.usernameMessage("kyle!!!!!!!"));
    }
    @Test void passwordMeets() {
        assertEquals("Password successfully captured.", login.passwordMessage("Ch&&sec@ke99!"));
    }
    @Test void passwordFails() {
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.",
                login.passwordMessage("password"));
    }
    @Test void cellCorrect() {
        assertEquals("Cell number successfully captured.", login.cellMessage("+27838968976"));
    }
    @Test void cellIncorrect() {
        assertEquals("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.",
                login.cellMessage("08966553"));
    }
    @Test void loginSuccessful() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }
    @Test void loginFailed() {
        login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertFalse(login.loginUser("kyl_1", "wrong"));
    }
    @Test void usernameBoolean() { assertTrue(login.checkUserName("kyl_1")); assertFalse(login.checkUserName("kyle!!!!!!!")); }
    @Test void passwordBoolean() { assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!")); assertFalse(login.checkPasswordComplexity("password")); }
    @Test void cellBoolean() { assertTrue(login.checkCellPhoneNumber("+27838968976")); assertFalse(login.checkCellPhoneNumber("08966553")); }
}
